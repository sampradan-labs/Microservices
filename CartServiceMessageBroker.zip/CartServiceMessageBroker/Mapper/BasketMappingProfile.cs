﻿using AutoMapper;
using CartServiceMessageBroker.Entities;
using EventBus.Messages.Events;

namespace CartServiceMessageBroker.Mapper
{
    public class BasketMappingProfile:Profile
    {
        public BasketMappingProfile()
        {
            CreateMap<BasketCheckout, BasketCheckoutEvent>().ReverseMap();
        }
    }
}
