﻿using Microsoft.EntityFrameworkCore;
using ProductsApi.Data;
using System.Diagnostics;

namespace ProductsApi.MigService
{
    public class DbMigrationService
    {
        public static void MigrationInit(IApplicationBuilder app)
        {

            using (var serviceScope = app.ApplicationServices.CreateScope())
            {
                try
                {
                    serviceScope.ServiceProvider.GetService<ProductsApiContext>().Database.Migrate();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
        }
    }
}
