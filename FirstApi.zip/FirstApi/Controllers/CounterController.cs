﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;

namespace FirstApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CounterController : ControllerBase
    {
        private readonly IDistributedCache _cache;

        public CounterController(IDistributedCache cache)
        {
            _cache = cache;
            if (String.IsNullOrEmpty(_cache.GetString("counter")))
                _cache.SetString("counter", "0");
        }

        [HttpGet("/counter")]
        public int GetCounter()
        {
            string strCountValue = _cache.GetString("counter");
            int intCounter = Convert.ToInt32(strCountValue);
            intCounter++;
            _cache.SetString("counter", intCounter.ToString());
            return intCounter;
        }
    }
}
