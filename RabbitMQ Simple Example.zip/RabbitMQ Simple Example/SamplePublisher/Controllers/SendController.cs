﻿using EventBus.Messages.Events;
using MassTransit;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SamplePublisher.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SendController : ControllerBase
    {
        private readonly IPublishEndpoint _publishEndpoint;

        public SendController(IPublishEndpoint publishEndpoint)
        {
            _publishEndpoint = publishEndpoint;
        }

        [HttpPost("/send")]
        public async Task<IActionResult> Send([FromBody] BasketCheckoutEvent msg)
        {
            await _publishEndpoint.Publish<BasketCheckoutEvent>(msg);
            return Ok();
        }
    }

    
}
