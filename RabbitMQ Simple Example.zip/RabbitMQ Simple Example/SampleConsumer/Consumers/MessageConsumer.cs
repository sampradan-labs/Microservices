﻿using EventBus.Messages.Events;
using MassTransit;
using System.Diagnostics;

namespace SampleConsumer.Consumers
{
    public class MessageConsumer : IConsumer<BasketCheckoutEvent>
    {
        public async Task Consume(ConsumeContext<BasketCheckoutEvent> context)
        {
            Debug.WriteLine(context.Message);
        }
    }
}
