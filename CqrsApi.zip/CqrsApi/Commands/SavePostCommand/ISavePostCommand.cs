﻿using CqrsApi.Models;

namespace CqrsApi.Commands.SavePostCommand
{
    public interface ISavePostCommand
    {        
        Task<Post> SavePost(string title, string body);
    }

    public interface ISavePostEvents
    {
        event EventHandler Sync;
    }
}
