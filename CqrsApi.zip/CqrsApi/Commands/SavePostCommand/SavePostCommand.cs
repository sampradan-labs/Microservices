﻿using AutoMapper;
using CqrsApi.Data;
using CqrsApi.Models;

namespace CqrsApi.Commands.SavePostCommand
{
    public class SavePostCommand : ISavePostCommand, ISavePostEvents
    {
        public event EventHandler Sync;

        private readonly CqrsApiContext _context;
        private readonly MapperConfiguration _config;
        private readonly IMapper _mapper;

        public SavePostCommand(CqrsApiContext context)
        {
            _context = context;

            //Attach the event
            if (Sync == null)
            {
                Sync += CommandService_Sync;
            }

            _config = new MapperConfiguration(cfg =>
                                                {
                                                    cfg.CreateMap<Post, ReadPost>().ReverseMap();

                                                });
            _mapper = _config.CreateMapper();
        }

        private void CommandService_Sync(object? sender, EventArgs e)
        {
            Thread.Sleep(500);
            if (Sync != null)
            {
                _context.PostsView.Add(sender as ReadPost);
                _context.SaveChanges(); //db update updating the PostView table
            }
            
        }

        public async Task<Post> SavePost(string title, string body)
        {
            Post newPost = new Post() { Title = title, Body = body };
           _context.Post.Add(newPost);
            //Trigger event to synchronize with read model
            ReadPost readPost = _mapper.Map<ReadPost>(newPost);
            Sync.Invoke(readPost, new EventArgs());
            _context.SaveChanges(); //db table update updating the Post table

            

            return newPost;
        }
    }
}
