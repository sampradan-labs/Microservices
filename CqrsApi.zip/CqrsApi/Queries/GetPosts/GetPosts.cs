﻿using CqrsApi.Models;
using Dapper;
using Microsoft.Data.SqlClient;

namespace CqrsApi.Queries.GetPosts
{
    public class GetPosts : IGetPosts
    {
        private readonly string _connectionString;

        public GetPosts(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IEnumerable<ReadPost> GetAllPosts()
        {
            using (var conn = new SqlConnection(_connectionString))
            {
                conn.Open();

                return conn.Query<ReadPost>("SELECT * FROM dbo.PostsView;");
            }
        }

       
    }
}
