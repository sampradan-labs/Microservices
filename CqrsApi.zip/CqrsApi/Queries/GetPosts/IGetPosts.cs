﻿using CqrsApi.Models;

namespace CqrsApi.Queries.GetPosts
{
    public interface IGetPosts
    {
        IEnumerable<ReadPost> GetAllPosts();
    }
}
