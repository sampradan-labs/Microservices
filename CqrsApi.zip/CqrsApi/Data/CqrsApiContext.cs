﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CqrsApi.Models;

namespace CqrsApi.Data
{
    public class CqrsApiContext : DbContext
    {
        public CqrsApiContext (DbContextOptions<CqrsApiContext> options)
            : base(options)
        {
        }

        public DbSet<CqrsApi.Models.Post> Post { get; set; } = default!;
        public DbSet<CqrsApi.Models.ReadPost> PostsView { get; set; } = default!;
    }
}
