﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CqrsApi.Data;
using CqrsApi.Models;
using CqrsApi.Commands.SavePostCommand;
using CqrsApi.Queries.GetPosts;
using CqrsApi.VM;

namespace CqrsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        private readonly CqrsApiContext _context;
        private readonly ISavePostCommand _saveCommand;
        private readonly IGetPosts _getPostsQuery;

        public PostsController(ISavePostCommand saveCommand, IGetPosts getPostsQuery)
        {
            _saveCommand = saveCommand;
            _getPostsQuery = getPostsQuery;
        }

        // GET api/values
        [HttpGet("/posts")]
        public async Task<ActionResult<IEnumerable<ReadPost>>> Get()
        {
            return (_getPostsQuery.GetAllPosts()).ToList();
        }



        // POST api/values
        [HttpPost("/add")]
        public void SavePost([FromBody] PostViewModel value)
        {
            _saveCommand.SavePost(value.Title, value.Body);
        }


    }
}
